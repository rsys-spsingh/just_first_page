<?php get_header(); ?>

<main>
    <!-- Banner Section -->
    <section class="banner-section">
        <div class="banner-container">
            <div class="banner-content">
                <span class="banner-icon">🎓</span>
                <span class="banner-text">We are the top admission provider in India. Provided successfully 1 lakh+ admissions</span>
                <span class="banner-badge">Trusted by Students</span>
            </div>
        </div>
    </section>

    <!-- Hero Section -->
    <section class="hero-section">
        <!-- Quote Section -->
        <div class="quote-section">
            <div class="quote-text">
                "Education is the most powerful weapon which you can use to change the world."
            </div>
            <div class="quote-author">- Nelson Mandela</div>
        </div>

        <!-- Contact Form -->
        <div class="form-section">
            <h2 class="form-title">Get Started Today</h2>
            <form id="contact-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="contact_form_submission">
                <?php wp_nonce_field('contact_form_nonce', 'contact_form_nonce'); ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" id="first_name" name="first_name" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" id="last_name" name="last_name" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="country_code">Country Code *</label>
                        <select id="country_code" name="country_code" required>
                            <option value="">Select Country</option>
                            <option value="+91">🇮🇳 India (+91)</option>
                            <option value="+1">🇺🇸 USA (+1)</option>
                            <option value="+1">🇨🇦 Canada (+1)</option>
                            <option value="+44">🇬🇧 UK (+44)</option>
                            <option value="+61">🇦🇺 Australia (+61)</option>
                            <option value="+49">🇩🇪 Germany (+49)</option>
                            <option value="+33">🇫🇷 France (+33)</option>
                            <option value="+81">🇯🇵 Japan (+81)</option>
                            <option value="+82">🇰🇷 South Korea (+82)</option>
                            <option value="+86">🇨🇳 China (+86)</option>
                            <option value="+971">🇦🇪 UAE (+971)</option>
                            <option value="+966">🇸🇦 Saudi Arabia (+966)</option>
                            <option value="+65">🇸🇬 Singapore (+65)</option>
                            <option value="+60">🇲🇾 Malaysia (+60)</option>
                            <option value="+66">🇹🇭 Thailand (+66)</option>
                            <option value="+62">🇮🇩 Indonesia (+62)</option>
                            <option value="+63">🇵🇭 Philippines (+63)</option>
                            <option value="+84">🇻🇳 Vietnam (+84)</option>
                            <option value="+880">🇧🇩 Bangladesh (+880)</option>
                            <option value="+94">🇱🇰 Sri Lanka (+94)</option>
                            <option value="+977">🇳🇵 Nepal (+977)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" id="phone" name="phone" placeholder="98765 43210" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="course">Select Course *</label>
                    <select id="course" name="course" required>
                        <option value="">Choose a course...</option>
                        <optgroup label="Master's Programs">
                            <option value="MBA">MBA</option>
                            <option value="MBA-Dual">MBA (Dual Specification)</option>
                            <option value="MBA-WX">MBA (WX)</option>
                            <option value="Executive-MBA">Executive MBA (1 year)</option>
                            <option value="MCA">MCA</option>
                            <option value="MCom">MCom</option>
                            <option value="MSc-Data-Science">MSc (Data Science)</option>
                            <option value="MA-Journalism">MA (Journalism & Mass Communication)</option>
                            <option value="MA-Public-Policy">MA (Public Policy & Governance)</option>
                        </optgroup>
                        <optgroup label="Bachelor's Programs">
                            <option value="BBA">BBA</option>
                            <option value="BCA">BCA</option>
                            <option value="BCom">BCom</option>
                            <option value="BA">BA</option>
                        </optgroup>
                        <optgroup label="Integrated Programs">
                            <option value="BCA-MCA">BCA + MCA</option>
                            <option value="BBA-MBA">BBA + MBA</option>
                            <option value="BCom-MBA">B.Com + MBA</option>
                            <option value="BCom-ACCA">B.Com + ACCA</option>
                        </optgroup>
                        <optgroup label="Certification & Diploma">
                            <option value="Cert-3Months">Certification Diploma (3 Months)</option>
                            <option value="Cert-6Months">Certification Diploma (6 Months)</option>
                            <option value="Diploma-1Year">Diploma (1 Year)</option>
                        </optgroup>
                    </select>
                </div>

                <button type="submit" class="submit-btn">Submit Application</button>
            </form>
        </div>
    </section>

    <!-- Course Catalog Section -->
    <section class="course-catalog-section">
        <div class="catalog-container">
            <h2 class="catalog-title">Our Course Catalog</h2>
            <p class="catalog-description">Explore our comprehensive range of programs designed to boost your career</p>
            
            <div class="catalog-layout">
                <!-- Category Sidebar -->
                <div class="category-sidebar">
                    <h3 class="sidebar-title">Course Categories</h3>
                    <div class="category-list">
                        <div class="category-item active" data-category="masters">
                            <div class="category-icon">🎓</div>
                            <div class="category-info">
                                <h4>Master's Programs</h4>
                                <p>Advanced degree programs</p>
                            </div>
                        </div>
                        <div class="category-item" data-category="bachelors">
                            <div class="category-icon">📚</div>
                            <div class="category-info">
                                <h4>Bachelor's Programs</h4>
                                <p>Undergraduate degrees</p>
                            </div>
                        </div>
                        <div class="category-item" data-category="integrated">
                            <div class="category-icon">🔗</div>
                            <div class="category-info">
                                <h4>Integrated Programs</h4>
                                <p>Combined degree courses</p>
                            </div>
                        </div>
                        <div class="category-item" data-category="diploma">
                            <div class="category-icon">📜</div>
                            <div class="category-info">
                                <h4>Diploma & Certification</h4>
                                <p>Short-term skill programs</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Course Content Area -->
                <div class="course-content-area">
                    <!-- Master's Programs -->
                    <div class="course-category-content active" id="masters-content">
                        <div class="category-header">
                            <h3>Master's Programs</h3>
                            <p>Advanced programs for career growth and specialization</p>
                        </div>
                        <div class="courses-grid">
                            <div class="course-card trending">
                                <div class="course-badge trending-badge">🔥 Trending</div>
                                <div class="course-header">
                                    <h4>MBA</h4>
                                    <span class="course-duration">2 Years</span>
                                </div>
                                <p class="course-description">Master of Business Administration - Build leadership skills and business acumen</p>
                                <div class="course-features">
                                    <span class="feature">✓ Industry Projects</span>
                                    <span class="feature">✓ Placement Assistance</span>
                                </div>
                                <div class="course-footer">
                                    <span class="seats-left">⚡ 25 Seats Left</span>
                                    <button class="apply-btn" onclick="selectCourse('MBA')">Apply Now</button>
                                </div>
                            </div>

                            <div class="course-card">
                                <div class="course-badge limited-badge">⚡ Few Seats Left</div>
                                <div class="course-header">
                                    <h4>MBA (Dual Specification)</h4>
                                    <span class="course-duration">2 Years</span>
                                </div>
                                <p class="course-description">Dual specialization in Finance & Marketing or HR & Operations</p>
                                <div class="course-features">
                                    <span class="feature">✓ Two Specializations</span>
                                    <span class="feature">✓ Industry Mentorship</span>
                                </div>
                                <div class="course-footer">
                                    <span class="seats-left">⚡ 8