document.addEventListener('DOMContentLoaded', function() {
    // Partner Slideshow functionality
    let slideIndex = 0;
    const slides = document.querySelectorAll('.slides');
    const dots = document.querySelectorAll('.dot');
    let slideInterval;

    function showSlide(n) {
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        if (slides.length > 0) {
            slides[n].classList.add('active');
            dots[n].classList.add('active');
        }
    }

    function nextSlide() {
        slideIndex = (slideIndex + 1) % slides.length;
        showSlide(slideIndex);
    }

    function currentSlide(n) {
        slideIndex = n - 1;
        showSlide(slideIndex);
        
        clearInterval(slideInterval);
        startAutoSlide();
    }

    function startAutoSlide() {
        slideInterval = setInterval(nextSlide, 4000);
    }

    window.currentSlide = currentSlide;

    if (slides.length > 0) {
        startAutoSlide();
    }

    const slideshowContainer = document.querySelector('.slideshow-container');
    if (slideshowContainer) {
        slideshowContainer.addEventListener('mouseenter', function() {
            clearInterval(slideInterval);
        });

        slideshowContainer.addEventListener('mouseleave', function() {
            startAutoSlide();
        });
    }

    // Expert Slideshow functionality
    let expertSlideIndex = 0;
    const expertSlides = document.querySelectorAll('.expert-slides');
    const expertDots = document.querySelectorAll('.expert-dot');
    let expertSlideInterval;

    function showExpertSlide(n) {
        expertSlides.forEach(slide => slide.classList.remove('active'));
        expertDots.forEach(dot => dot.classList.remove('active'));

        if (expertSlides.length > 0) {
            expertSlides[n].classList.add('active');
            expertDots[n].classList.add('active');
        }
    }

    function nextExpertSlide() {
        expertSlideIndex = (expertSlideIndex + 1) % expertSlides.length;
        showExpertSlide(expertSlideIndex);
    }

    function currentExpertSlide(n) {
        expertSlideIndex = n - 1;
        showExpertSlide(expertSlideIndex);
        
        clearInterval(expertSlideInterval);
        startExpertAutoSlide();
    }

    function startExpertAutoSlide() {
        expertSlideInterval = setInterval(nextExpertSlide, 5000);
    }

    window.currentExpertSlide = currentExpertSlide;

    if (expertSlides.length > 0) {
        startExpertAutoSlide();
    }

    const expertSlideshowContainer = document.querySelector('.experts-slideshow-container');
    if (expertSlideshowContainer) {
        expertSlideshowContainer.addEventListener('mouseenter', function() {
            clearInterval(expertSlideInterval);
        });

        expertSlideshowContainer.addEventListener('mouseleave', function() {
            startExpertAutoSlide();
        });
    }

    // Course Catalog functionality
    const categoryItems = document.querySelectorAll('.category-item');
    const courseContents = document.querySelectorAll('.course-category-content');

    categoryItems.forEach(item => {
        item.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            
            categoryItems.forEach(cat => cat.classList.remove('active'));
            this.classList.add('active');
            
            courseContents.forEach(content => content.classList.remove('active'));
            
            const targetContent = document.getElementById(category + '-content');
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });

    // Apply Now button functionality
    window.selectCourse = function(courseValue) {
        const form = document.getElementById('contact-form');
        if (form) {
            form.scrollIntoView({ behavior: 'smooth' });
            
            const courseSelect = document.getElementById('course');
            if (courseSelect) {
                courseSelect.value = courseValue;
                
                courseSelect.style.borderColor = '#28a745';
                setTimeout(() => {
                    courseSelect.style.borderColor = '#e1e5e9';
                }, 2000);
                
                courseSelect.dispatchEvent(new Event('change'));
            }
            
            form.style.boxShadow = '0 0 20px rgba(30, 60, 114, 0.3)';
            setTimeout(() => {
                form.style.boxShadow = '';
            }, 2000);
        }
    };

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('nav a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Form validation enhancement
    const form = document.getElementById('contact-form');
    if (form) {
        const inputs = form.querySelectorAll('input[required], select[required]');
        
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearError(this);
            });
            
            input.addEventListener('change', function() {
                clearError(this);
            });
        });
        
        form.addEventListener('submit', function(e) {
            let isValid = true;
            
            clearFormMessages();
            
            inputs.forEach(input => {
                if (!validateField(input)) {
                    isValid = false;
                }
            });
            
            if (isValid) {
                const submitBtn = form.querySelector('.submit-btn');
                submitBtn.innerHTML = 'Submitting Application...';
                submitBtn.disabled = true;
                submitBtn.classList.add('loading');
            } else {
                e.preventDefault();
            }
        });
    }
    
    function validateField(field) {
        const value = field.value.trim();
        
        clearError(field);
        
        if (field.hasAttribute('required') && !value) {
            showError(field, 'This field is required');
            return false;
        }
        
        if (field.type === 'email' && value && !isValidEmail(value)) {
            showError(field, 'Please enter a valid email address');
            return false;
        }
        
        if (field.type === 'tel' && value && !isValidPhone(value)) {
            showError(field, 'Please enter a valid phone number');
            return false;
        }
        
        if (field.id === 'country_code' && value && !isValidCountryCode(value)) {
            showError(field, 'Please select a valid country code');
            return false;
        }
        
        return true;
    }
    
    function showError(field, message) {
        const fieldGroup = field.closest('.form-group');
        field.style.borderColor = '#dc3545';
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        fieldGroup.appendChild(errorDiv);
    }
    
    function clearError(field) {
        const fieldGroup = field.closest('.form-group');
        const existingError = fieldGroup.querySelector('.error-message');
        
        if (existingError) {
            existingError.remove();
        }
        
        field.style.borderColor = '#e1e5e9';
    }

    function clearFormMessages() {
        const errorMessages = document.querySelectorAll('.error-message');
        errorMessages.forEach(msg => msg.remove());
        
        const fields = document.querySelectorAll('input, select');
        fields.forEach(field => {
            field.style.borderColor = '#e1e5e9';
        });
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    function isValidPhone(phone) {
        const phoneRegex = /^[\d\s\-\(\)]{7,15}$/;
        const cleanPhone = phone.replace(/\s+/g, '').replace(/[-()]/g, '');
        return phoneRegex.test(phone) && cleanPhone.length >= 7;
    }

    function isValidCountryCode(code) {
        const validCodes = ['+91', '+1', '+44', '+61', '+49', '+33', '+81', '+82', '+86', 
                           '+971', '+966', '+65', '+60', '+66', '+62', '+63', '+84', '+880', '+94', '+977'];
        return validCodes.includes(code);
    }

    // Enhanced phone number formatting
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^+\d\s\-()]/g, '');
        });
    }

    // Auto-select India as default country code
    const countryCodeSelect = document.getElementById('country_code');
    if (countryCodeSelect) {
        countryCodeSelect.value = '+91';
    }

    // Course selection enhancement with visual feedback
    const courseSelect = document.getElementById('course');
    if (courseSelect) {
        courseSelect.addEventListener('change', function() {
            if (this.value) {
                clearError(this);
                this.style.borderColor = '#28a745';
                setTimeout(() => {
                    this.style.borderColor = '#e1e5e9';
                }, 2000);
            }
        });
    }

    // Add visual feedback for country code selection
    if (countryCodeSelect) {
        countryCodeSelect.addEventListener('change', function() {
            if (this.value) {
                clearError(this);
                this.style.borderColor = '#28a745';
                setTimeout(() => {
                    this.style.borderColor = '#e1e5e9';
                }, 2000);
            }
        });
    }

    // Add number animation for expert stats
    function animateNumbers() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        statNumbers.forEach(number => {
            const finalNumber = parseInt(number.textContent.replace(/[^\d]/g, ''));
            let current = 0;
            const increment = finalNumber / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= finalNumber) {
                    number.textContent = number.textContent;
                    clearInterval(timer);
                } else {
                    number.textContent = Math.floor(current) + '+';
                }
            }, 50);
        });
    }

    // Trigger number animation when experts section comes into view
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateNumbers();
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    const expertsSection = document.querySelector('.experts-section');
    if (expertsSection) {
        observer.observe(expertsSection);
    }

    // Floating buttons functionality
    const floatingButtons = document.querySelectorAll('.floating-btn');
    
    floatingButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            const buttonType = this.classList.contains('phone-btn') ? 'phone' : 'whatsapp';
            console.log(`${buttonType} button clicked`);
        });

        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.1)';
        });

        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0px) scale(1)';
        });
    });

    // Hide floating buttons when scrolling to footer to avoid overlap
    const footer = document.querySelector('footer');
    const stickyButtons = document.querySelector('.sticky-buttons');
    
    if (footer && stickyButtons) {
        const checkFooterVisibility = () => {
            const footerRect = footer.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (footerRect.top < windowHeight) {
                const overlap = windowHeight - footerRect.top + 20;
                stickyButtons.style.bottom = `${20 + overlap}px`;
            } else {
                stickyButtons.style.bottom = '20px';
            }
        };

        window.addEventListener('scroll', checkFooterVisibility);
        window.addEventListener('resize', checkFooterVisibility);
        checkFooterVisibility();
    }
});

// Global functions for comparison page
window.openComparisonPage = function() {
    const comparisonUrl = window.location.origin + '/compare-courses/';
    window.open(comparisonUrl, '_blank');
};

window.openComparison = function(courses) {
    const comparisonUrl = window.location.origin + '/compare-courses/?courses=' + courses.join(',');
    window.open(comparisonUrl, '_blank');
};

window.openUniversityComparison = function() {
    const comparisonUrl = window.location.origin + '/compare-courses/#university-comparison-section';
    window.open(comparisonUrl, '_blank');
};

// Comparison page functionality (only loads on comparison page)
if (document.querySelector('.comparison-page')) {
    
    // Course selection functionality
    document.addEventListener('DOMContentLoaded', function() {
        const courseOptions = document.querySelectorAll('.course-option');
        const compareBtn = document.querySelector('.compare-btn');
        let selectedCourses = [];

        // Handle course selection
        courseOptions.forEach(option => {
            const checkbox = option.querySelector('input[type="checkbox"]');
            
            option.addEventListener('click', function(e) {
                if (e.target.type !== 'checkbox') {
                    checkbox.checked = !checkbox.checked;
                }
                
                const course = this.getAttribute('data-course');
                
                if (checkbox.checked) {
                    this.classList.add('selected');
                    if (!selectedCourses.includes(course)) {
                        selectedCourses.push(course);
                    }
                } else {
                    this.classList.remove('selected');
                    selectedCourses = selectedCourses.filter(c => c !== course);
                }
                
                updateCompareButton();
            });
        });

        function updateCompareButton() {
            if (selectedCourses.length >= 2) {
                compareBtn.disabled = false;
                compareBtn.textContent = `Compare ${selectedCourses.length} Courses`;
            } else {
                compareBtn.disabled = true;
                compareBtn.textContent = 'Select at least 2 courses to compare';
            }
        }

        updateCompareButton();

        // Check for pre-selected courses from URL
        const urlParams = new URLSearchParams(window.location.search);
        const preSelectedCourses = urlParams.get('courses');
        if (preSelectedCourses) {
            const courses = preSelectedCourses.split(',');
            courses.forEach(course => {
                const option = document.querySelector(`[data-course="${course}"]`);
                if (option) {
                    const checkbox = option.querySelector('input[type="checkbox"]');
                    checkbox.checked = true;
                    option.classList.add('selected');
                    selectedCourses.push(course);
                }
            });
            updateCompareButton();
            setTimeout(() => generateComparison(), 500);
        }
    });

    // Generate comparison function
    window.generateComparison = function() {
        const selectedCourses = Array.from(document.querySelectorAll('.course-option.selected'))
            .map(option => option.getAttribute('data-course'));

        if (selectedCourses.length < 2) {
            alert('Please select at least 2 courses to compare');
            return;
        }

        const resultsSection = document.getElementById('comparison-results');
        resultsSection.style.display = 'block';
        resultsSection.scrollIntoView({ behavior: 'smooth' });

        generateTableView(selectedCourses);
        generateCardView(selectedCourses);
    };

    // Clear selection function
    window.clearSelection = function() {
        document.querySelectorAll('.course-option').forEach(option => {
            option.classList.remove('selected');
            option.querySelector('input[type="checkbox"]').checked = false;
        });
        
        document.getElementById('comparison-results').style.display = 'none';
        
        const compareBtn = document.querySelector('.compare-btn');
        compareBtn.disabled = true;
        compareBtn.textContent = 'Select at least 2 courses to compare';
    };

    // Generate table view
    function generateTableView(selectedCourses) {
        const table = document.getElementById('comparison-table');
        const thead = table.querySelector('thead tr');
        const tbody = table.querySelector('tbody');
        
        thead.innerHTML = '<th class="criteria-column">Criteria</th>';
        tbody.innerHTML = '';
        
        selectedCourses.forEach(course => {
            const th = document.createElement('th');
            th.textContent = courseData[course].name;
            th.style.minWidth = '200px';
            thead.appendChild(th);
        });
        
        const criteria = [
            { key: 'duration', label: 'Duration' },
            { key: 'fees', label: 'Total Fees' },
            { key: 'eligibility', label: 'Eligibility' },
            { key: 'placement', label: 'Placement Rate' },
            { key: 'avgSalary', label: 'Average Salary' },
            { key: 'ranking', label: 'Ranking' },
            { key: 'approval', label: 'Approvals' },
            { key: 'naac', label: 'NAAC Score' },
            { key: 'specializations', label: 'Specializations' },
            { key: 'topRecruiters', label: 'Top Recruiters' },
            { key: 'careerOptions', label: 'Career Options' }
        ];
        
        criteria.forEach(criterion => {
            const tr = document.createElement('tr');
            
            const criteriaCell = document.createElement('td');
            criteriaCell.className = 'criteria-cell';
            criteriaCell.textContent = criterion.label;
            tr.appendChild(criteriaCell);
            
            selectedCourses.forEach(course => {
                const td = document.createElement('td');
                td.textContent = courseData[course][criterion.key] || 'N/A';
                tr.appendChild(td);
            });
            
            tbody.appendChild(tr);
        });
    }

    // Generate card view
    function generateCardView(selectedCourses) {
        const cardContainer = document.getElementById('card-view');
        cardContainer.innerHTML = '';
        
        selectedCourses.forEach(course => {
            const data = courseData[course];
            const card = document.createElement('div');
            card.className = 'comparison-card';
            
            card.innerHTML = `
                <div class="comparison-card-header">
                    <h3>${data.name}</h3>
                    <div class="course-duration-badge">${data.duration}</div>
                </div>
                <div class="comparison-details">
                    <div class="detail-row">
                        <span class="detail-label">Total Fees</span>
                        <span class="detail-value">${data.fees}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Eligibility</span>
                        <span class="detail-value">${data.eligibility}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Placement Rate</span>
                        <span class="detail-value">${data.placement}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Average Salary</span>
                        <span class="detail-value">${data.avgSalary}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Ranking</span>
                        <span class="detail-value">${data.ranking}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Approvals</span>
                        <span class="detail-value">${data.approval}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">NAAC Score</span>
                        <span class="detail-value">${data.naac}</span>
                    </div>
                </div>
                <div style="margin-top: 20px; text-align: center;">
                    <button class="apply-btn" onclick="selectCourse('${course}')">Apply for ${data.name}</button>
                </div>
            `;
            
            cardContainer.appendChild(card);
        });
    }

    // Switch view function
    window.switchView = function(view) {
        const tableView = document.getElementById('table-view');
        const cardView = document.getElementById('card-view');
        const toggleBtns = document.querySelectorAll('.toggle-btn');
        
        toggleBtns.forEach(btn => btn.classList.remove('active'));
        
        if (view === 'table') {
            tableView.style.display = 'block';
            cardView.style.display = 'none';
            document.querySelector('.toggle-btn[onclick="switchView(\'table\')"]').classList.add('active');
        } else {
            tableView.style.display = 'none';
            cardView.style.display = 'block';
            document.querySelector('.toggle-btn[onclick="switchView(\'card\')"]').classList.add('active');
        }
    };

    // University details modal functions
    window.showUniversityDetails = function(universityName) {
        const modal = document.getElementById('university-modal');
        const modalTitle = document.getElementById('modal-university-name');
        const modalBody = document.getElementById('modal-body');
        
        const university = universityDetails[universityName];
        
        modalTitle.textContent = university.fullName;
        
        modalBody.innerHTML = `
            <div class="university-detail-grid">
                <div class="detail-section">
                    <h4>Basic Information</h4>
                    <p><strong>Established:</strong> ${university.established}</p>
                    <p><strong>Location:</strong> ${university.location}</p>
                    <p><strong>Type:</strong> ${university.type}</p>
                    <p><strong>Accreditation:</strong> ${university.accreditation}</p>
                </div>
                <div class="detail-section">
                    <h4>Academic Details</h4>
                    <p><strong>Ranking:</strong> ${university.ranking}</p>
                    <p><strong>Total Fees:</strong> ${university.totalFees}</p>
                    <p><strong>Placement Rate:</strong> ${university.placementRate}</p>
                    <p><strong>Admission Process:</strong> ${university.admissionProcess}</p>
                </div>
            </div>
            <div class="detail-section">
                <h4>Courses Offered</h4>
                <p>${university.coursesOffered.join(', ')}</p>
            </div>
            <div class="detail-section">
                <h4>Key Highlights</h4>
                <ul class="highlight-list">
                    ${university.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
                </ul>
            </div>
        `;
        
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    };

    window.closeUniversityModal = function() {
        document.getElementById('university-modal').style.display = 'none';
        document.body.style.overflow = 'auto';
    };

    // Close modal on outside click
    document.getElementById('university-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeUniversityModal();
        }
    });

    // Close modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeUniversityModal();
        }
    });
}