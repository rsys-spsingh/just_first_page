<?php
/*
Template Name: Compare Courses
*/
get_header();
?>

<main class="comparison-page">
    <!-- Page Header -->
    <section class="comparison-header">
        <div class="container">
            <h1 class="page-title">Compare Courses & Universities</h1>
            <p class="page-description">Make an informed decision by comparing fees, placements, rankings, and more</p>
        </div>
    </section>

    <!-- Course Selection -->
    <section class="course-selection-section">
        <div class="container">
            <h2>Select Courses to Compare</h2>
            <div class="course-selector">
                <div class="selector-grid">
                    <div class="course-option" data-course="MBA">
                        <div class="course-icon">🎓</div>
                        <h4>MBA</h4>
                        <p>2 Years</p>
                        <input type="checkbox" id="mba-check" value="MBA">
                    </div>
                    <div class="course-option" data-course="MBA-Dual">
                        <div class="course-icon">🎯</div>
                        <h4>MBA (Dual)</h4>
                        <p>2 Years</p>
                        <input type="checkbox" id="mba-dual-check" value="MBA-Dual">
                    </div>
                    <div class="course-option" data-course="Executive-MBA">
                        <div class="course-icon">⚡</div>
                        <h4>Executive MBA</h4>
                        <p>1 Year</p>
                        <input type="checkbox" id="exec-mba-check" value="Executive-MBA">
                    </div>
                    <div class="course-option" data-course="MCA">
                        <div class="course-icon">💻</div>
                        <h4>MCA</h4>
                        <p>2 Years</p>
                        <input type="checkbox" id="mca-check" value="MCA">
                    </div>
                    <div class="course-option" data-course="BCA">
                        <div class="course-icon">🔧</div>
                        <h4>BCA</h4>
                        <p>3 Years</p>
                        <input type="checkbox" id="bca-check" value="BCA">
                    </div>
                    <div class="course-option" data-course="BBA">
                        <div class="course-icon">📊</div>
                        <h4>BBA</h4>
                        <p>3 Years</p>
                        <input type="checkbox" id="bba-check" value="BBA">
                    </div>
                    <div class="course-option" data-course="BCom">
                        <div class="course-icon">💰</div>
                        <h4>B.Com</h4>
                        <p>3 Years</p>
                        <input type="checkbox" id="bcom-check" value="BCom">
                    </div>
                    <div class="course-option" data-course="BCA-MCA">
                        <div class="course-icon">🔗</div>
                        <h4>BCA + MCA</h4>
                        <p>5 Years</p>
                        <input type="checkbox" id="bca-mca-check" value="BCA-MCA">
                    </div>
                </div>
                <div class="compare-actions">
                    <button class="compare-btn" onclick="generateComparison()">Compare Selected Courses</button>
                    <button class="clear-btn" onclick="clearSelection()">Clear All</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Comparison Results -->
    <section class="comparison-results" id="comparison-results" style="display: none;">
        <div class="container">
            <div class="results-header">
                <h2>Course Comparison Results</h2>
                <div class="view-toggle">
                    <button class="toggle-btn active" onclick="switchView('table')">Table View</button>
                    <button class="toggle-btn" onclick="switchView('card')">Card View</button>
                </div>
            </div>
            
            <!-- Table View -->
            <div class="comparison-table-container" id="table-view">
                <div class="comparison-table-wrapper">
                    <table class="comparison-table" id="comparison-table">
                        <thead>
                            <tr>
                                <th class="criteria-column">Criteria</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Card View -->
            <div class="comparison-cards" id="card-view" style="display: none;">
            </div>
        </div>
    </section>

    <!-- University Comparison -->
    <section class="university-comparison-section">
        <div class="container">
            <h2>Top Universities Comparison</h2>
            <p class="section-description">Compare leading universities offering these programs</p>
            
            <div class="university-grid">
                <div class="university-card">
                    <div class="university-header">
                        <div class="university-logo">
                            <img src="https://via.placeholder.com/80x80/1e3c72/ffffff?text=IGNOU" alt="IGNOU">
                        </div>
                        <div class="university-info">
                            <h3>IGNOU</h3>
                            <p>Indira Gandhi National Open University</p>
                            <div class="university-rating">
                                <span class="rating">4.2 ⭐</span>
                                <span class="naac">NAAC A+</span>
                            </div>
                        </div>
                    </div>
                    <div class="university-details">
                        <div class="detail-item">
                            <span class="label">Ranking:</span>
                            <span class="value">#15 (Distance Learning)</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fees Range:</span>
                            <span class="value">₹15,000 - ₹85,000</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Placement:</span>
                            <span class="value">75%</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Approvals:</span>
                            <span class="value">UGC, AICTE, DEB</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Eligibility:</span>
                            <span class="value">12th / Graduation</span>
                        </div>
                    </div>
                    <div class="university-actions">
                        <button class="info-btn" onclick="showUniversityDetails('IGNOU')">More Info</button>
                        <button class="apply-btn" onclick="selectCourse('MBA')">Apply Now</button>
                    </div>
                </div>

                <div class="university-card">
                    <div class="university-header">
                        <div class="university-logo">
                            <img src="https://via.placeholder.com/80x80/2a5298/ffffff?text=LPU" alt="LPU">
                        </div>
                        <div class="university-info">
                            <h3>LPU</h3>
                            <p>Lovely Professional University</p>
                            <div class="university-rating">
                                <span class="rating">4.1 ⭐</span>
                                <span class="naac">NAAC A+</span>
                            </div>
                        </div>
                    </div>
                    <div class="university-details">
                        <div class="detail-item">
                            <span class="label">Ranking:</span>
                            <span class="value">#52 (Overall)</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fees Range:</span>
                            <span class="value">₹45,000 - ₹2,50,000</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Placement:</span>
                            <span class="value">85%</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Approvals:</span>
                            <span class="value">UGC, AICTE, PCI</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Eligibility:</span>
                            <span class="value">12th / Graduation</span>
                        </div>
                    </div>
                    <div class="university-actions">
                        <button class="info-btn" onclick="showUniversityDetails('LPU')">More Info</button>
                        <button class="apply-btn" onclick="selectCourse('BCA')">Apply Now</button>
                    </div>
                </div>

                <div class="university-card">
                    <div class="university-header">
                        <div class="university-logo">
                            <img src="https://via.placeholder.com/80x80/667eea/ffffff?text=AMITY" alt="Amity">
                        </div>
                        <div class="university-info">
                            <h3>Amity University</h3>
                            <p>Amity University Online</p>
                            <div class="university-rating">
                                <span class="rating">4.3 ⭐</span>
                                <span class="naac">NAAC A+</span>
                            </div>
                        </div>
                    </div>
                    <div class="university-details">
                        <div class="detail-item">
                            <span class="label">Ranking:</span>
                            <span class="value">#35 (Private)</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fees Range:</span>
                            <span class="value">₹75,000 - ₹3,50,000</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Placement:</span>
                            <span class="value">90%</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Approvals:</span>
                            <span class="value">UGC, AICTE, BCI</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Eligibility:</span>
                            <span class="value">12th / Graduation</span>
                        </div>
                    </div>
                    <div class="university-actions">
                        <button class="info-btn" onclick="showUniversityDetails('Amity')">More Info</button>
                        <button class="apply-btn" onclick="selectCourse('MBA')">Apply Now</button>
                    </div>
                </div>

                <div class="university-card">
                    <div class="university-header">
                        <div class="university-logo">
                            <img src="https://via.placeholder.com/80x80/764ba2/ffffff?text=JAIN" alt="Jain">
                        </div>
                        <div class="university-info">
                            <h3>Jain University</h3>
                            <p>Jain Online</p>
                            <div class="university-rating">
                                <span class="rating">4.0 ⭐</span>
                                <span class="naac">NAAC A++</span>
                            </div>
                        </div>
                    </div>
                    <div class="university-details">
                        <div class="detail-item">
                            <span class="label">Ranking:</span>
                            <span class="value">#42 (Overall)</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fees Range:</span>
                            <span class="value">₹55,000 - ₹2,75,000</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Placement:</span>
                            <span class="value">82%</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Approvals:</span>
                            <span class="value">UGC, AICTE, NCTE</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Eligibility:</span>
                            <span class="value">12th / Graduation</span>
                        </div>
                    </div>
                    <div class="university-actions">
                        <button class="info-btn" onclick="showUniversityDetails('Jain')">More Info</button>
                        <button class="apply-btn" onclick="selectCourse('BBA')">Apply Now</button>
                    </div>
                </div>

                <div class="university-card">
                    <div class="university-header">
                        <div class="university-logo">
                            <img src="https://via.placeholder.com/80x80/ee5a24/ffffff?text=MANIPAL" alt="Manipal">
                        </div>
                        <div class="university-info">
                            <h3>Manipal University</h3>
                            <p>Manipal University Jaipur</p>
                            <div class="university-rating">
                                <span class="rating">4.4 ⭐</span>
                                <span class="naac">NAAC A++</span>
                            </div>
                        </div>
                    </div>
                    <div class="university-details">
                        <div class="detail-item">
                            <span class="label">Ranking:</span>
                            <span class="value">#28 (Overall)</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fees Range:</span>
                            <span class="value">₹85,000 - ₹4,50,000</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Placement:</span>
                            <span class="value">95%</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Approvals:</span>
                            <span class="value">UGC, AICTE, MCI</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Eligibility:</span>
                            <span class="value">12th / Graduation</span>
                        </div>
                    </div>
                    <div class="university-actions">
                        <button class="info-btn" onclick="showUniversityDetails('Manipal')">More Info</button>
                        <button class="apply-btn" onclick="selectCourse('MCA')">Apply Now</button>
                    </div>
                </div>

                <div class="university-card">
                    <div class="university-header">
                        <div class="university-logo">
                            <img src="https://via.placeholder.com/80x80/48dbfb/ffffff?text=DU" alt="Delhi University">
                        </div>
                        <div class="university-info">
                            <h3>Delhi University</h3>
                            <p>School of Open Learning</p>
                            <div class="university-rating">
                                <span class="rating">4.5 ⭐</span>
                                <span class="naac">NAAC A++</span>
                            </div>
                        </div>
                    </div>
                    <div class="university-details">
                        <div class="detail-item">
                            <span class="label">Ranking:</span>
                            <span class="value">#8 (Overall)</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fees Range:</span>
                            <span class="value">₹12,000 - ₹65,000</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Placement:</span>
                            <span class="value">88%</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Approvals:</span>
                            <span class="value">UGC, MHRD</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Eligibility:</span>
                            <span class="value">12th / Graduation</span>
                        </div>
                    </div>
                    <div class="university-actions">
                        <button class="info-btn" onclick="showUniversityDetails('DU')">More Info</button>
                        <button class="apply-btn" onclick="selectCourse('BCom')">Apply Now</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal for University Details -->
<div class="modal" id="university-modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modal-university-name">University Details</h2>
            <span class="close-modal" onclick="closeUniversityModal()">&times;</span>
        </div>
        <div class="modal-body" id="modal-body">
        </div>
        <div class="modal-footer">
            <button class="modal-btn apply-btn" onclick="selectCourse('MBA')">Apply Now</button>
            <button class="modal-btn secondary-btn" onclick="closeUniversityModal()">Close</button>
        </div>
    </div>
</div>

<script>
// Course comparison data
const courseData = {
    'MBA': {
        name: 'MBA',
        duration: '2 Years',
        fees: '₹1,50,000 - ₹3,50,000',
        placement: '85-95%',
        eligibility: 'Graduation (Any Stream)',
        ranking: 'Top 20 Programs',
        approval: 'AICTE, UGC',
        naac: 'A+ to A++',
        specializations: 'Finance, Marketing, HR, Operations',
        avgSalary: '₹6-12 LPA',
        topRecruiters: 'TCS, Infosys, Wipro, HDFC',
        careerOptions: 'Manager, Consultant, Analyst'
    },
    'MBA-Dual': {
        name: 'MBA (Dual Specification)',
        duration: '2 Years',
        fees: '₹1,80,000 - ₹4,00,000',
        placement: '88-92%',
        eligibility: 'Graduation (Any Stream)',
        ranking: 'Top 25 Programs',
        approval: 'AICTE, UGC',
        naac: 'A+ to A++',
        specializations: 'Finance+Marketing, HR+Operations',
        avgSalary: '₹7-14 LPA',
        topRecruiters: 'Deloitte, PwC, EY, KPMG',
        careerOptions: 'Senior Manager, Business Analyst'
    },
    'Executive-MBA': {
        name: 'Executive MBA',
        duration: '1 Year',
        fees: '₹2,00,000 - ₹5,00,000',
        placement: '90-98%',
        eligibility: '3+ Years Work Experience',
        ranking: 'Top 15 Programs',
        approval: 'AICTE, UGC',
        naac: 'A++',
        specializations: 'Leadership, Strategy, Innovation',
        avgSalary: '₹12-25 LPA',
        topRecruiters: 'McKinsey, BCG, Bain & Co',
        careerOptions: 'Director, VP, CEO'
    },
    'MCA': {
        name: 'MCA',
        duration: '2 Years',
        fees: '₹85,000 - ₹2,50,000',
        placement: '80-90%',
        eligibility: 'BCA/B.Sc (CS/IT)',
        ranking: 'Top 30 Programs',
        approval: 'AICTE, UGC',
        naac: 'A to A+',
        specializations: 'Software Development, Data Science, AI',
        avgSalary: '₹4-8 LPA',
        topRecruiters: 'Google, Microsoft, Amazon, Adobe',
        careerOptions: 'Software Engineer, Developer, Analyst'
    },
    'BCA': {
        name: 'BCA',
        duration: '3 Years',
        fees: '₹45,000 - ₹1,50,000',
        placement: '70-85%',
        eligibility: '12th (Any Stream)',
        ranking: 'Popular UG Program',
        approval: 'UGC',
        naac: 'A to A+',
        specializations: 'Programming, Web Development, Database',
        avgSalary: '₹3-6 LPA',
        topRecruiters: 'Cognizant, Capgemini, IBM, Accenture',
        careerOptions: 'Developer, Programmer, Tester'
    },
    'BBA': {
        name: 'BBA',
        duration: '3 Years',
        fees: '₹65,000 - ₹2,00,000',
        placement: '75-85%',
        eligibility: '12th (Any Stream)',
        ranking: 'Popular UG Program',
        approval: 'UGC, AICTE',
        naac: 'A to A+',
        specializations: 'Finance, Marketing, HR',
        avgSalary: '₹3-5 LPA',
        topRecruiters: 'Flipkart, Zomato, Paytm, BYJU\'S',
        careerOptions: 'Executive, Coordinator, Analyst'
    },
    'BCom': {
        name: 'B.Com',
        duration: '3 Years',
        fees: '₹25,000 - ₹85,000',
        placement: '65-75%',
        eligibility: '12th (Commerce Preferred)',
        ranking: 'Traditional UG Program',
        approval: 'UGC',
        naac: 'A to A+',
        specializations: 'Accounting, Taxation, Finance',
        avgSalary: '₹2.5-4 LPA',
        topRecruiters: 'Banking Sector, CA Firms, Govt Jobs',
        careerOptions: 'Accountant, Tax Consultant, Banker'
    },
    'BCA-MCA': {
        name: 'BCA + MCA',
        duration: '5 Years',
        fees: '₹1,25,000 - ₹3,50,000',
        placement: '85-95%',
        eligibility: '12th (Any Stream)',
        ranking: 'Integrated Program',
        approval: 'UGC, AICTE',
        naac: 'A+ to A++',
        specializations: 'Full Stack Development, AI/ML, Cloud',
        avgSalary: '₹5-10 LPA',
        topRecruiters: 'Tech Giants, Product Companies',
        careerOptions: 'Senior Developer, Tech Lead, Architect'
    }
};

// University details data
const universityDetails = {
    'IGNOU': {
        fullName: 'Indira Gandhi National Open University',
        established: '1985',
        location: 'New Delhi',
        type: 'Central University',
        accreditation: 'NAAC A+, UGC Recognized',
        ranking: '#15 in Distance Learning',
        totalFees: '₹15,000 - ₹85,000',
        placementRate: '75%',
        coursesOffered: ['MBA', 'MCA', 'BCA', 'B.Com', 'BA'],
        highlights: [
            'Largest open university in the world',
            'Affordable education with quality',
            'Flexible learning schedule',
            'Strong alumni network'
        ],
        admissionProcess: 'Online application, Merit-based selection',
        duration: 'Various programs from 6 months to 3 years'
    },
    'LPU': {
        fullName: 'Lovely Professional University',
        established: '2005',
        location: 'Punjab',
        type: 'Private University',
        accreditation: 'NAAC A+, UGC Recognized',
        ranking: '#52 Overall in India',
        totalFees: '₹45,000 - ₹2,50,000',
        placementRate: '85%',
        coursesOffered: ['MBA', 'MCA', 'BCA', 'BBA', 'B.Com'],
        highlights: [
            'Modern campus with latest facilities',
            'Strong industry connections',
            'International exposure programs',
            'High placement rate'
        ],
        admissionProcess: 'Entrance exam (LPUNEST), Merit-based',
        duration: 'Standard program duration'
    },
    'Amity': {
        fullName: 'Amity University Online',
        established: '2005',
        location: 'Noida, UP',
        type: 'Private University',
        accreditation: 'NAAC A+, UGC Recognized',
        ranking: '#35 among Private Universities',
        totalFees: '₹75,000 - ₹3,50,000',
        placementRate: '90%',
        coursesOffered: ['MBA', 'MCA', 'B