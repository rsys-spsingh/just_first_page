<?php
// Theme setup
function edupro_theme_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => 'Primary Menu',
    ));
}
add_action('after_setup_theme', 'edupro_theme_setup');

// Enqueue styles and scripts
function edupro_scripts() {
    wp_enqueue_style('edupro-style', get_stylesheet_uri(), array(), '1.7.0');
    wp_enqueue_script('edupro-script', get_template_directory_uri() . '/js/script.js', array(), '1.7.0', true);
}
add_action('wp_enqueue_scripts', 'edupro_scripts');

// Create database table for form submissions when theme is activated
function create_contact_submissions_table() {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'degree_drishti_submissions';
    
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id int(11) NOT NULL AUTO_INCREMENT,
        first_name varchar(100) NOT NULL,
        last_name varchar(100) NOT NULL,
        email varchar(150) NOT NULL,
        country_code varchar(10) NOT NULL,
        phone varchar(20) NOT NULL,
        course varchar(100) NOT NULL,
        submission_date datetime DEFAULT CURRENT_TIMESTAMP,
        ip_address varchar(45),
        user_agent text,
        status varchar(20) DEFAULT 'new',
        notes text,
        PRIMARY KEY (id),
        INDEX email_idx (email),
        INDEX course_idx (course),
        INDEX date_idx (submission_date),
        INDEX status_idx (status)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Log table creation
    error_log('Degree Drishti: Contact submissions table created - ' . $table_name);
}

// Hook to create table when theme is activated
add_action('after_switch_theme', 'create_contact_submissions_table');

// Also create table on theme init if it doesn't exist
function check_submissions_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'degree_drishti_submissions';
    
    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        create_contact_submissions_table();
    }
}
add_action('init', 'check_submissions_table');

// Handle contact form submission
function handle_contact_form_submission() {
    // Check if this is a form submission
    if (!isset($_POST['action']) || $_POST['action'] !== 'contact_form_submission') {
        wp_die('Invalid form submission');
    }
    
    // Verify nonce for security
    if (!wp_verify_nonce($_POST['contact_form_nonce'], 'contact_form_nonce')) {
        wp_die('Security check failed. Please try again.');
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'degree_drishti_submissions';
    
    // Sanitize and validate form data
    $first_name = sanitize_text_field(trim($_POST['first_name'] ?? ''));
    $last_name = sanitize_text_field(trim($_POST['last_name'] ?? ''));
    $email = sanitize_email(trim($_POST['email'] ?? ''));
    $country_code = sanitize_text_field(trim($_POST['country_code'] ?? ''));
    $phone = sanitize_text_field(trim($_POST['phone'] ?? ''));
    $course = sanitize_text_field(trim($_POST['course'] ?? ''));
    
    // Server-side validation
    $errors = array();
    
    if (empty($first_name)) {
        $errors[] = 'First name is required';
    }
    
    if (empty($last_name)) {
        $errors[] = 'Last name is required';
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!is_email($email)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    if (empty($country_code)) {
        $errors[] = 'Country code is required';
    }
    
    if (empty($phone)) {
        $errors[] = 'Phone number is required';
    } elseif (!preg_match('/^[\d\s\-\(\)]{7,15}$/', $phone)) {
        $errors[] = 'Please enter a valid phone number';
    }
    
    if (empty($course)) {
        $errors[] = 'Course selection is required';
    }
    
    // Valid courses list
    $valid_courses = array(
        'MBA', 'MBA-Dual', 'MBA-WX', 'Executive-MBA', 'MCA', 'MCom', 'MSc-Data-Science', 
        'MA-Journalism', 'MA-Public-Policy', 'BBA', 'BCA', 'BCom', 'BA',
        'BCA-MCA', 'BBA-MBA', 'BCom-MBA', 'BCom-ACCA', 
        'Cert-3Months', 'Cert-6Months', 'Diploma-1Year'
    );
    
    if (!in_array($course, $valid_courses)) {
        $errors[] = 'Please select a valid course';
    }
    
    // Valid country codes
    $valid_country_codes = array(
        '+91', '+1', '+44', '+61', '+49', '+33', '+81', '+82', '+86', 
        '+971', '+966', '+65', '+60', '+66', '+62', '+63', '+84', '+880', '+94', '+977'
    );
    
    if (!in_array($country_code, $valid_country_codes)) {
        $errors[] = 'Please select a valid country code';
    }
    
    // Check for duplicate email submissions within last 24 hours
    $recent_submission = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE email = %s AND submission_date > DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            $email
        )
    );
    
    if ($recent_submission) {
        $errors[] = 'You have already submitted an application in the last 24 hours. Please try again later.';
    }
    
    // If there are validation errors, redirect with error message
    if (!empty($errors)) {
        $error_message = implode(', ', $errors);
        wp_redirect(home_url('/?error=validation&message=' . urlencode($error_message)));
        exit;
    }
    
    // Get additional data
    $ip_address = get_client_ip();
    $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? '');
    $submission_time = current_time('mysql');
    
    // Insert data into database
    $result = $wpdb->insert(
        $table_name,
        array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'country_code' => $country_code,
            'phone' => $phone,
            'course' => $course,
            'submission_date' => $submission_time,
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'status' => 'new'
        ),
        array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
    );
    
    if ($result === false) {
        // Log the error
        error_log('Database insertion failed: ' . $wpdb->last_error);
        wp_redirect(home_url('/?error=database_error'));
        exit;
    }
    
    // Get the inserted ID
    $submission_id = $wpdb->insert_id;
    
    // Send notification email to admin
    $admin_email = get_option('admin_email');
    $site_name = get_bloginfo('name');
    
    $subject = "New Course Application #{$submission_id} - {$site_name}";
    
    $message = "New application received:\n\n";
    $message .= "Application ID: #{$submission_id}\n";
    $message .= "Name: {$first_name} {$last_name}\n";
    $message .= "Email: {$email}\n";
    $message .= "Phone: {$country_code} {$phone}\n";
    $message .= "Course: {$course}\n";
    $message .= "Submitted: " . date('F j, Y g:i a', strtotime($submission_time)) . "\n";
    $message .= "IP Address: {$ip_address}\n\n";
    $message .= "View all submissions in WordPress Admin > Submissions\n";
    
    // Send email
    $mail_sent = wp_mail($admin_email, $subject, $message);
    
    if (!$mail_sent) {
        error_log('Failed to send notification email for submission ID: ' . $submission_id);
    }
    
    // Send confirmation email to user
    send_user_confirmation_email($email, $first_name, $course, $submission_id);
    
    // Log successful submission
    error_log("New submission saved: ID #{$submission_id}, Email: {$email}, Course: {$course}");
    
    // Redirect with success message
    wp_redirect(home_url('/?success=form_submitted&id=' . $submission_id));
    exit;
}

// Helper function to get client IP
function get_client_ip() {
    $ip_keys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
    
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            $ip = $_SERVER[$key];
            if (strpos($ip, ',') !== false) {
                $ip = explode(',', $ip)[0];
            }
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

// Send confirmation email to user
function send_user_confirmation_email($email, $first_name, $course, $submission_id) {
    $site_name = get_bloginfo('name');
    $subject = "Application Confirmation #{$submission_id} - {$site_name}";
    
    $message = "Dear {$first_name},\n\n";
    $message .= "Thank you for your interest in our programs!\n\n";
    $message .= "We have received your application for: {$course}\n";
    $message .= "Application ID: #{$submission_id}\n\n";
    $message .= "Our admissions team will review your application and contact you within 24-48 hours.\n\n";
    $message .= "If you have any questions, please feel free to contact us:\n";
    $message .= "Email: info@degreedrishti.com\n";
    $message .= "Phone: +91 98765 43210\n\n";
    $message .= "Best regards,\n";
    $message .= "Degree Drishti Admissions Team\n";
    
    wp_mail($email, $subject, $message);
}

// Hook the form handler
add_action('admin_post_contact_form_submission', 'handle_contact_form_submission');
add_action('admin_post_nopriv_contact_form_submission', 'handle_contact_form_submission');

// Display form messages
function display_form_messages() {
    if (isset($_GET['success']) && $_GET['success'] == 'form_submitted') {
        $submission_id = isset($_GET['id']) ? '#' . sanitize_text_field($_GET['id']) : '';
        echo '<div class="success-message">
            🎉 Thank you! Your application ' . $submission_id . ' has been submitted successfully. 
            We will contact you within 24-48 hours. Check your email for confirmation details.
        </div>';
    }
    
    if (isset($_GET['error'])) {
        $error_message = '';
        switch ($_GET['error']) {
            case 'validation':
                $error_message = isset($_GET['message']) ? urldecode($_GET['message']) : 'Please check your form data and try again.';
                break;
            case 'database_error':
                $error_message = 'There was an error saving your submission. Please try again or contact us directly.';
                break;
            default:
                $error_message = 'An error occurred. Please try again.';
        }
        echo '<div class="error-alert">' . esc_html($error_message) . '</div>';
    }
}
add_action('wp_footer', 'display_form_messages');

// Add admin menu for viewing submissions
function add_submissions_admin_menu() {
    add_menu_page(
        'Course Applications',
        'Submissions',
        'manage_options',
        'degree-drishti-submissions',
        'display_submissions_admin_page',
        'dashicons-email-alt',
        30
    );
    
    add_submenu_page(
        'degree-drishti-submissions',
        'Export Submissions',
        'Export Data',
        'manage_options',
        'export-submissions',
        'export_submissions_page'
    );
}
add_action('admin_menu', 'add_submissions_admin_menu');

// Display submissions in admin with enhanced features
function display_submissions_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'degree_drishti_submissions';
    
    // Handle status updates
    if (isset($_POST['update_status']) && isset($_POST['submission_id']) && isset($_POST['new_status'])) {
        $submission_id = intval($_POST['submission_id']);
        $new_status = sanitize_text_field($_POST['new_status']);
        
        $wpdb->update(
            $table_name,
            array('status' => $new_status),
            array('id' => $submission_id),
            array('%s'),
            array('%d')
        );
        
        echo '<div class="notice notice-success"><p>Status updated successfully!</p></div>';
    }
    
    // Get filter parameters
    $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
    $course_filter = isset($_GET['course']) ? sanitize_text_field($_GET['course']) : '';
    $date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
    $date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';
    
    // Build query with filters
    $where_conditions = array('1=1');
    $where_values = array();
    
    if ($status_filter) {
        $where_conditions[] = 'status = %s';
        $where_values[] = $status_filter;
    }
    
    if ($course_filter) {
        $where_conditions[] = 'course = %s';
        $where_values[] = $course_filter;
    }
    
    if ($date_from) {
        $where_conditions[] = 'DATE(submission_date) >= %s';
        $where_values[] = $date_from;
    }
    
    if ($date_to) {
        $where_conditions[] = 'DATE(submission_date) <= %s';
        $where_values[] = $date_to;
    }
    
    $where_clause = implode(' AND ', $where_conditions);
    
    if (!empty($where_values)) {
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE $where_clause ORDER BY submission_date DESC", $where_values);
    } else {
        $query = "SELECT * FROM $table_name WHERE $where_clause ORDER BY submission_date DESC";
    }
    
    $submissions = $wpdb->get_results($query);
    
    // Get statistics
    $total_submissions = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $new_submissions = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'new'");
    $today_submissions = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE DATE(submission_date) = CURDATE()");
    
    ?>
    <div class="wrap">
        <h1>Course Applications</h1>
        
        <!-- Statistics -->
        <div style="display: flex; gap: 20px; margin: 20px 0;">
            <div style="background: #f0f0f1; padding: 15px; border-radius: 5px; min-width: 120px; text-align: center;">
                <h3 style="margin: 0; color: #1e3c72;"><?php echo $total_submissions; ?></h3>
                <p style="margin: 5px 0 0 0;">Total Applications</p>
            </div>
            <div style="background: #fff3cd; padding: 15px; border-radius: 5px; min-width: 120px; text-align: center;">
                <h3 style="margin: 0; color: #856404;"><?php echo $new_submissions; ?></h3>
                <p style="margin: 5px 0 0 0;">New Applications</p>
            </div>
            <div style="background: #d4edda; padding: 15px; border-radius: 5px; min-width: 120px; text-align: center;">
                <h3 style="margin: 0; color: #155724;"><?php echo $today_submissions; ?></h3>
                <p style="margin: 5px 0 0 0;">Today's Applications</p>
            </div>
        </div>
        
        <!-- Filters -->
        <form method="GET" style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <input type="hidden" name="page" value="degree-drishti-submissions">
            <div style="display: flex; gap: 15px; flex-wrap: wrap; align-items: end;">
                <div>
                    <label>Status:</label><br>
                    <select name="status" style="padding: 5px;">
                        <option value="">All Status</option>
                        <option value="new" <?php selected($status_filter, 'new'); ?>>New</option>
                        <option value="contacted" <?php selected($status_filter, 'contacted'); ?>>Contacted</option>
                        <option value="enrolled" <?php selected($status_filter, 'enrolled'); ?>>Enrolled</option>
                        <option value="rejected" <?php selected($status_filter, 'rejected'); ?>>Rejected</option>
                    </select>
                </div>
                <div>
                    <label>Course:</label><br>
                    <select name="course" style="padding: 5px;">
                        <option value="">All Courses</option>
                        <option value="MBA" <?php selected($course_filter, 'MBA'); ?>>MBA</option>
                        <option value="BCA" <?php selected($course_filter, 'BCA'); ?>>BCA</option>
                        <option value="MCA" <?php selected($course_filter, 'MCA'); ?>>MCA</option>
                    </select>
                </div>
                <div>
                    <label>Date From:</label><br>
                    <input type="date" name="date_from" value="<?php echo $date_from; ?>" style="padding: 5px;">
                </div>
                <div>
                    <label>Date To:</label><br>
                    <input type="date" name="date_to" value="<?php echo $date_to; ?>" style="padding: 5px;">
                </div>
                <div>
                    <input type="submit" value="Filter" class="button">
                    <a href="<?php echo admin_url('admin.php?page=degree-drishti-submissions'); ?>" class="button">Reset</a>
                </div>
            </div>
        </form>
        
        <!-- Results count -->
        <p><strong><?php echo count($submissions); ?> applications found</strong></p>
        
        <!-- Submissions Table -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($submissions)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            <em>No applications found matching your criteria.</em>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><strong>#<?php echo $submission->id; ?></strong></td>
                            <td><?php echo date('M j, Y g:i a', strtotime($submission->submission_date)); ?></td>
                            <td><?php echo esc_html($submission->first_name . ' ' . $submission->last_name); ?></td>
                            <td><a href="mailto:<?php echo esc_attr($submission->email); ?>"><?php echo esc_html($submission->email); ?></a></td>
                            <td><?php echo esc_html($submission->country_code . ' ' . $submission->phone); ?></td>
                            <td><span style="background: #e7f3ff; padding: 3px 8px; border-radius: 3px; font-size: 12px;"><?php echo esc_html($submission->course); ?></span></td>
                            <td>
                                <?php
                                $status_colors = array(
                                    'new' => '#ffc107',
                                    'contacted' => '#17a2b8',
                                    'enrolled' => '#28a745',
                                    'rejected' => '#dc3545'
                                );
                                $status_color = $status_colors[$submission->status] ?? '#6c757d';
                                ?>
                                <span style="background: <?php echo $status_color; ?>; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">
                                    <?php echo ucfirst($submission->status); ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="submission_id" value="<?php echo $submission->id; ?>">
                                    <select name="new_status" style="font-size: 12px;">
                                        <option value="new" <?php selected($submission->status, 'new'); ?>>New</option>
                                        <option value="contacted" <?php selected($submission->status, 'contacted'); ?>>Contacted</option>
                                        <option value="enrolled" <?php selected($submission->status, 'enrolled'); ?>>Enrolled</option>
                                        <option value="rejected" <?php selected($submission->status, 'rejected'); ?>>Rejected</option>
                                    </select>
                                    <input type="submit" name="update_status" value="Update" class="button-small">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <br>
        <p>
            <a href="<?php echo admin_url('admin.php?page=export-submissions'); ?>" class="button button-primary">
                Export All Data to CSV
            </a>
        </p>
    </div>
    <?php
}

// Export submissions to CSV
function export_submissions_page() {
    if (isset($_POST['export_csv'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'degree_drishti_submissions';
        
        $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submission_date DESC", ARRAY_A);
        
        // Set headers for CSV download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=degree_drishti_submissions_' . date('Y-m-d_H-i-s') . '.csv');
        
        // Create file pointer
        $output = fopen('php://output', 'w');
        
        // Add CSV headers
        fputcsv($output, array(
            'ID', 'First Name', 'Last Name', 'Email', 'Country Code', 'Phone', 
            'Course', 'Status', 'Submission Date', 'IP Address'
        ));
        
        // Add data rows
        foreach ($submissions as $submission) {
            fputcsv($output, array(
                $submission['id'],
                $submission['first_name'],
                $submission['last_name'],
                $submission['email'],
                $submission['country_code'],
                $submission['phone'],
                $submission['course'],
                $submission['status'],
                $submission['submission_date'],
                $submission['ip_address']
            ));
        }
        
        fclose($output);
        exit;
    }
    
    ?>
    <div class="wrap">
        <h1>Export Submissions</h1>
        <p>Download all form submissions as a CSV file for external analysis.</p>
        
        <form method="POST">
            <p>
                <input type="submit" name="export_csv" value="Download CSV File" class="button button-primary">
            </p>
        </form>
    </div>
    <?php
}

// Handle comparison page template
function load_comparison_page_template($template) {
    if (is_page('compare-courses')) {
        $new_template = locate_template(array('compare-courses.php'));
        if (!empty($new_template)) {
            return $new_template;
        }
    }
    return $template;
}
add_filter('template_include', 'load_comparison_page_template', 99);

// Create comparison page automatically
function create_comparison_page() {
    $page_title = 'Compare Courses';
    $page_content = 'This is the course comparison page.';
    $page_template = 'compare-courses.php';
    
    $page_check = get_page_by_title($page_title);
    
    if(!isset($page_check->ID)) {
        $new_page = array(
            'post_type' => 'page',
            'post_title' => $page_title,
            'post_content' => $page_content,
            'post_status' => 'publish',
            'post_slug' => 'compare-courses'
        );
        
        $page_id = wp_insert_post($new_page);
        
        if(!empty($page_template)) {
            update_post_meta($page_id, '_wp_page_template', $page_template);
        }
    }
}
add_action('after_switch_theme', 'create_comparison_page');

// Remove admin bar for non-admin users
if (!current_user_can('administrator')) {
    show_admin_bar(false);
}
?>